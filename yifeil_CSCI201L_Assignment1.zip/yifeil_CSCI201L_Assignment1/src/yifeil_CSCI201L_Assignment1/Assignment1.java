package yifeil_CSCI201L_Assignment1;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class Assignment1 {
	public static void main(String [] args) {
		try {	
			System.out.print("What is the name of the input file? ");
			Scanner scanner = new Scanner(System.in);
			String filename = scanner.next();
			
	         File inputFile = new File(filename);
	          
	         DocumentBuilderFactory dbFactory 
	            = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile); //parse input file
	         doc.getDocumentElement().normalize();
	         
	         //parse school
	         NodeList nSchools = doc.getElementsByTagName("school");
	         school[] schools = new school[nSchools.getLength()];
	         for (int iSchool = 0; iSchool < nSchools.getLength(); iSchool++) {
	        	 Node nSchool = nSchools.item(iSchool);
	        	 if (nSchool.getNodeType() == Node.ELEMENT_NODE) {
	        		Element eSchool = (Element) nSchool;
	        		schools[iSchool] = new school();
	        		schools[iSchool].name = eSchool.getAttribute("name");
	        		 
	        		 //parse department
	        		 NodeList nDepartments = eSchool.getElementsByTagName("department");
	    	         department[] departments = new department[nDepartments.getLength()];
	    	         for (int iDepartment = 0; iDepartment < nDepartments.getLength(); iDepartment++) {
	    	        	 Node nDepartment = nDepartments.item(iDepartment);
	    	        	 if (nDepartment.getNodeType() == Node.ELEMENT_NODE) {
	    	        		 Element eDepartment = (Element)nDepartment;
	    	        		 departments[iDepartment] = new department();
	    	        		 if (eDepartment.getElementsByTagName("longName").getLength() != 0)
	    	        			 departments[iDepartment].longName = eDepartment.getElementsByTagName("longName").item(0).getTextContent();
	    	        		 if (eDepartment.getElementsByTagName("prefix").getLength() != 0)
	    	        			 departments[iDepartment].prefix = eDepartment.getElementsByTagName("prefix").item(0).getTextContent();
	    	        		 
	    	        		 //parse courses
	    	        		 if (eDepartment.getElementsByTagName("courses").getLength() != 0) {	    	        			
		    	        		 Node nCourses_temp = eDepartment.getElementsByTagName("courses").item(0);
		    	        		 if (nCourses_temp.getNodeType() == Node.ELEMENT_NODE) {
		    	        			 Element eCourses_temp = (Element)nCourses_temp;
		    	        			 NodeList nCourses = eCourses_temp.getElementsByTagName("course");
		    	        			 course[] courses = new course[nCourses.getLength()];
			    	        		 for (int iCourse = 0; iCourse < nCourses.getLength(); iCourse++) {
			    	        			 Node nCourse = nCourses.item(iCourse);
			    	        			 if (nCourse.getNodeType() == Node.ELEMENT_NODE) {
			    	    	        		 Element eCourse = (Element)nCourse;
			    	    	        		 courses[iCourse] = new course();
			    	    	        		 if (eCourse.getElementsByTagName("number").getLength() != 0)
			    	    	        			 courses[iCourse].number = Integer.parseInt(eCourse.getElementsByTagName("number").item(0).getTextContent());
			    	    	        		 if (eCourse.getElementsByTagName("term").getLength() != 0)
			    	    	        			 courses[iCourse].term = eCourse.getElementsByTagName("term").item(0).getTextContent();
			    	    	        		 if (eCourse.getElementsByTagName("year").getLength() != 0)
			    	    	        			 courses[iCourse].year = Integer.parseInt(eCourse.getElementsByTagName("year").item(0).getTextContent());
			    	    	        		 
			    	    	        		 //parse staff members
			    	    	        		 if (eCourse.getElementsByTagName("staffMembers").getLength() != 0) {
				    	    	        		 Node nStaffMembers_temp = eCourse.getElementsByTagName("staffMembers").item(0);
				    	    	        		 if (nStaffMembers_temp.getNodeType() == Node.ELEMENT_NODE) {
				    	    	        			 Element eStaffMembers_temp = (Element)nStaffMembers_temp;
				    	    	        			 NodeList nStaffMembers = eStaffMembers_temp.getElementsByTagName("staffMember");
				    	    	        			 staffmember[] staffmembers = new staffmember[nStaffMembers.getLength()];
					    	    	        		 for (int iStaffMember = 0; iStaffMember < nStaffMembers.getLength(); iStaffMember++) {
					    	    	        			 Node nStaffMember = nStaffMembers.item(iStaffMember);
					    	    	        			 if (nStaffMember.getNodeType() == Node.ELEMENT_NODE) {
					    	    	        				 Element eStaffMember = (Element)nStaffMember;
					    	    	        				 staffmembers[iStaffMember] = new staffmember();
					    	    	        				 //if (eStaffMember.getAttribute("type").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].type = eStaffMember.getAttribute("type");
					    	    	        				 //if (eStaffMember.getAttribute("id").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].id = Integer.parseInt(eStaffMember.getAttribute("id"));
					    	    	        				 if (eStaffMember.getElementsByTagName("fname").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].fname = eStaffMember.getElementsByTagName("fname").item(0).getTextContent();
					    	    	        				 if (eStaffMember.getElementsByTagName("lname").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].lname = eStaffMember.getElementsByTagName("lname").item(0).getTextContent();
					    	    	        				 if (eStaffMember.getElementsByTagName("email").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].email = eStaffMember.getElementsByTagName("email").item(0).getTextContent();
					    	    	        				 if (eStaffMember.getElementsByTagName("image").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].image = eStaffMember.getElementsByTagName("image").item(0).getTextContent();
					    	    	        				 if (eStaffMember.getElementsByTagName("phone").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].phone = eStaffMember.getElementsByTagName("phone").item(0).getTextContent();
					    	    	        				 if (eStaffMember.getElementsByTagName("office").getLength() != 0) 
					    	    	        					 staffmembers[iStaffMember].office = eStaffMember.getElementsByTagName("office").item(0).getTextContent();
					    	    	        				 
					    	    	        				 //parse office hours
					    	    	        				 if (eStaffMember.getElementsByTagName("officeHours").getLength() != 0) {
						    	    	        				 Node nOfficeHours_temp = eStaffMember.getElementsByTagName("officeHours").item(0);
								    	    	        		 if (nOfficeHours_temp.getNodeType() == Node.ELEMENT_NODE) {
								    	    	        			 Element eOfficeHours_temp = (Element)nOfficeHours_temp;
								    	    	        			 NodeList nOfficeHours = eOfficeHours_temp.getElementsByTagName("officeHour");
								    	    	        			 officeHour[] officeHours = new officeHour[nOfficeHours.getLength()];
							    	    	        				 for (int iOfficeHour = 0; iOfficeHour < nOfficeHours.getLength(); iOfficeHour++) {
							    	    	        					 Node nOfficeHour = nOfficeHours.item(iOfficeHour);
							    	    	        					 if (nOfficeHour.getNodeType() == Node.ELEMENT_NODE) {
							    	    	        						 Element eOfficeHour = (Element)nOfficeHour;
							    	    	        						 officeHours[iOfficeHour] = new officeHour();
							    	    	        						 if (eOfficeHour.getElementsByTagName("day").getLength() != 0) 
							    	    	        							 officeHours[iOfficeHour].day = eOfficeHour.getElementsByTagName("day").item(0).getTextContent();
							    	    	        						 //parse time
							    	    	        						 if (eOfficeHour.getElementsByTagName("time").getLength() != 0) {
							    	    	        							 Node nTime = eOfficeHour.getElementsByTagName("time").item(0);
								    			    	    	        		 if (nTime.getNodeType() == Node.ELEMENT_NODE) {
								    			    	    	        			 Element eTime = (Element)nTime;
								    			    	    	        			 Time time = new Time();
								    			    	    	        			 if (eTime.getElementsByTagName("start").getLength() != 0)
								    			    	    	        				 time.start =  eTime.getElementsByTagName("start").item(0).getTextContent();
								    			    	    	        			 if (eTime.getElementsByTagName("end").getLength() != 0)
								    			    	    	        				 time.end = eTime.getElementsByTagName("end").item(0).getTextContent();
									    	    	        						 officeHours[iOfficeHour].time = time;
								    			    	    	        		 }
							    	    	        						 } 
							    	    	        						 
							    	    	        					 }
							    	    	        				 }
							    	    	        				 staffmembers[iStaffMember].officeHours = officeHours;	
								    	    	        		 }
							    	    	        		 }		     	    	        					 
					    	    	        			 }
					    	    	        		 }				    	    	        		
					    	    	        		 courses[iCourse].staffmembers = staffmembers;
				    	    	        		 }
		    	    	        		 	}
	    	        		 
			    	    	        		 //parse meetings
			    	    	        		 if (eCourse.getElementsByTagName("meetings").getLength() != 0) {
				    	    	        		 Node nMeetings_temp = eCourse.getElementsByTagName("meetings").item(0);
				    	    	        		 if (nMeetings_temp.getNodeType() == Node.ELEMENT_NODE) {
				    	    	        			 Element eMeetings_temp = (Element)nMeetings_temp;
				    	    	        			 NodeList nMeetings = eMeetings_temp.getElementsByTagName("meeting");
				    	    	        			 meeting[] meetings = new meeting[nMeetings.getLength()];
					    	    	        		 for (int iMeeting = 0; iMeeting < nMeetings.getLength(); iMeeting++) {
					    	    	        			 Node nMeeting = nMeetings.item(iMeeting);
					    	    	        			 if (nMeeting.getNodeType() == Node.ELEMENT_NODE) {
					    	    	        				 Element eMeeting = (Element)nMeeting;
					    	    	        				 meetings[iMeeting] = new meeting();
					    	    	        				 meetings[iMeeting].type = eMeeting.getAttribute("type");
					    	    	        				 if (eMeeting.getElementsByTagName("section").getLength() != 0)
					    	    	        					 meetings[iMeeting].section = eMeeting.getElementsByTagName("section").item(0).getTextContent();
					    	    	        				 if (eMeeting.getElementsByTagName("room").getLength() != 0)
					    	    	        					 meetings[iMeeting].room = eMeeting.getElementsByTagName("room").item(0).getTextContent();
					    	    	        				 
					    	    	        				 //parse meeting periods
					    	    	        				 if (eMeeting.getElementsByTagName("meetingPeriods").getLength() != 0) {
								    	    	        		 Node nMeetingPeriods_temp = eMeeting.getElementsByTagName("meetingPeriods").item(0);
								    	    	        		 if (nMeetingPeriods_temp.getNodeType() == Node.ELEMENT_NODE) {
								    	    	        			 Element eMeetingPeriods_temp = (Element)nMeetingPeriods_temp;
								    	    	        			 NodeList nMeetingPeriods = eMeetingPeriods_temp.getElementsByTagName("meetingPeriod");
								    	    	        			 meetingPeriod[] meetingPeriods = new meetingPeriod[nMeetingPeriods.getLength()];
							    	    	        				 for (int iMeetingPeriod = 0; iMeetingPeriod < nMeetingPeriods.getLength(); iMeetingPeriod++) {
							    	    	        					 Node nMeetingPeriod = nMeetingPeriods.item(iMeetingPeriod);
							    	    	        					 if (nMeetingPeriod.getNodeType() == Node.ELEMENT_NODE) {
							    	    	        						 Element eMeetingPeriod = (Element)nMeetingPeriod;
							    	    	        						 meetingPeriods[iMeetingPeriod] = new meetingPeriod();
							    	    	        						 if (eMeetingPeriod.getElementsByTagName("day").getLength() != 0)
							    	    	        							 meetingPeriods[iMeetingPeriod].day = eMeetingPeriod.getElementsByTagName("day").item(0).getTextContent();
							    	    	        						 //parse time
							    	    	        						 if (eMeetingPeriod.getElementsByTagName("time").getLength() != 0) {
							    	    	        							 Node nTime = eMeetingPeriod.getElementsByTagName("time").item(0);
								    			    	    	        		 if (nTime.getNodeType() == Node.ELEMENT_NODE) {
								    			    	    	        			 Element eTime = (Element)nTime;
								    			    	    	        			 Time time = new Time();
								    			    	    	        			 if (eTime.getElementsByTagName("start").getLength() != 0)
								    			    	    	        				 time.start =  eTime.getElementsByTagName("start").item(0).getTextContent();
								    			    	    	        			 if (eTime.getElementsByTagName("end").getLength() != 0)
								    			    	    	        				 time.end = eTime.getElementsByTagName("end").item(0).getTextContent();
								    			    	    	        			 meetingPeriods[iMeetingPeriod].time = time;
								    			    	    	        		 }
							    	    	        						 }		        						 
							    	    	        					 }
							    	    	        				 }
							    	    	        				 meetings[iMeeting].meetingPeriods = meetingPeriods;
								    	    	        		 }
							    	    	        		 }
					    	    	        				 
					    	    	        				 
					    	    	        				//parse assistant	
					    	    	        				 if (eMeeting.getElementsByTagName("assistants").getLength() != 0) {
								    	    	        		 Node nAssistants_temp = eMeeting.getElementsByTagName("assistants").item(0);
								    	    	        		 if (nAssistants_temp.getNodeType() == Node.ELEMENT_NODE) {
								    	    	        			 Element eAssistants_temp = (Element)nAssistants_temp;
								    	    	        			 NodeList nAssistants = eAssistants_temp.getElementsByTagName("assistant");
								    	    	        			 assistant[] assistants = new assistant[nAssistants.getLength()];
									    	    	        		 for (int iAssistant = 0; iAssistant < nAssistants.getLength(); iAssistant++) {
									    	    	        			 Node nAssistant = nAssistants.item(iAssistant);
									    	    	        			 if (nAssistant.getNodeType() == Node.ELEMENT_NODE) {
									    	    	        				 Element eAssistant = (Element)nAssistant;
									    	    	        				 assistants[iAssistant] = new assistant();
									    	    	        				 assistants[iAssistant].staffMemberID = Integer.parseInt(eAssistant.getAttribute("staffMemberID"));
									    	    	        			 }
									    	    	        		 }
									    	    	        		 meetings[iMeeting].assistants = assistants;
								    	    	        		 }
							    	    	        		 }	   
					    	    	        			 }		 
					    	    	        		 }
					    	    	        		 courses[iCourse].meetings = meetings;
				    	    	        		 }
			    	    	        		 }			    	    	        		 
			    	        			 }
			    	        		 }
			    	        		 departments[iDepartment].courses = courses;
	    	        		 	}
	    	        		 }	 
	    	        	 }
	    	         }
	    	         schools[iSchool].departments = departments; 
	    	         
	        	 }
	         }
	         
	         //display main menu
	         boolean flag1 = true;
	         while (flag1) {
	 			System.out.println();
	 			System.out.println("1) Display schools");
	 			System.out.println("2) Exit");
	 			System.out.println("What would you like to do? ");
	 			scanner = new Scanner(System.in);
	 			int option1 = scanner.nextInt();		
	 			if (option1 == 1) {
	 				//display schools
	 				boolean flag2 = true;
	 				while (flag2) {
	 					int size2 = schools.length;		
	 					System.out.println();
	 					System.out.println("Schools");
	 					for (int i = 1; i <= size2 + 2; i++) {
	 						if (i <= size2) {
	 							System.out.println(i + ") " + schools[i - 1].name );
	 						} else if (i == size2 + 1) {
	 							System.out.println(i + ") Go to main menu");
	 						} else {
	 							System.out.println(i + ") Exit");
	 						}
	 					}
	 					System.out.println("What would you like to do? ");
	 					scanner = new Scanner(System.in);
	 					int option2 = scanner.nextInt();	
	 					
	 					if (option2 <= size2) {
	 						//display departments
	 						boolean flag3 = true;
	 						while (flag3) {
	 							department[] departments = schools[option2 - 1].departments;		
	 							int size3 = departments.length;	
	 							System.out.println();
	 							System.out.println("Departments");
	 							for (int i = 1; i <= size3 + 2; i++) {
	 								if (i <= size3) {
	 									System.out.println(i + ") " + departments[i - 1].longName + " (" + departments[i - 1].prefix + ")" );
	 								} else if (i == size3 + 1) {
	 									System.out.println(i + ") Go to Schools menu");
	 								} else {
	 									System.out.println(i + ") Exit");
	 								}
	 							}
	 							System.out.println("What would you like to do? ");
	 							scanner = new Scanner(System.in);
	 							int option3 = scanner.nextInt();	
	 							
	 							if (option3 <= size3) {
	 								//display courses
	 								boolean flag4 = true;
	 								while (flag4) {
	 									course[] courses = departments[option3 - 1].courses;
	 									int size4 = courses.length;	
	 									System.out.println();
	 									System.out.println(departments[option3 - 1].prefix + " Courses");
	 									for (int i = 1; i <= size4 + 2; i++) {
	 										if (i <= size4) {
	 											System.out.println(i + ") " + departments[option3 - 1].prefix + " " + courses[i - 1].number + " " + courses[i - 1].term + " " + courses[i - 1].year );
	 										} else if (i == size4 + 1) {
	 											System.out.println(i + ") Go to Departments menu");
	 										} else {
	 											System.out.println(i + ") Exit");
	 										}
	 									}
	 									System.out.println("What would you like to do? ");
	 									scanner = new Scanner(System.in);
	 									int option4 = scanner.nextInt();	
	 									
	 									if (option4 <= size4) {
	 										//display course details
	 										boolean flag5 = true;
	 										while (flag5) {
	 											staffmember[] staffmembers = courses[option4 - 1].staffmembers;
	 											meeting[] meetings = courses[option4 - 1].meetings;
	 											
	 											System.out.println();
	 											System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 											System.out.println("1) View course staff");
	 											System.out.println("2) View meeting information");
	 											System.out.println("3) Go to Courses menu");
	 											System.out.println("4) Exit");
	 											System.out.println("What would you like to do? ");
	 											scanner = new Scanner(System.in);
	 											int option5 = scanner.nextInt();	
	 											
	 											if (option5 == 1) {
	 												//display course staff
	 												boolean flag6 = true;
	 												while (flag6) {
	 													System.out.println();
	 													System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 													System.out.println("Course Staff");
	 													System.out.println("1) View Instructors");
	 													System.out.println("2) View TAs");
	 													System.out.println("3) View CPs");
	 													System.out.println("4) View Graders");
	 													System.out.println("5) Go to " + departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year + " Menu");
	 													System.out.println("6) Exit");
	 													System.out.println("What would you like to do? ");
	 													scanner = new Scanner(System.in);
	 													int option6 = scanner.nextInt();
	 													
	 													if (option6 == 1) {
	 														//display instructors
	 														for (int i = 0; i < staffmembers.length; i++) {
	 															if (staffmembers[i].type.equals("instructor")) {
	 																staffmember curr = staffmembers[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("Instructor");
	 			 													if (curr.fname != null && curr.lname != null)
	 			 														System.out.println("Name: " + curr.fname + " " + curr.lname);
	 			 													if (curr.email != null)
	 			 														System.out.println("Email: " + curr.email);
	 			 													if (curr.image != null)
	 			 														System.out.println("Image: " + curr.image);
	 			 													if (curr.phone != null)
	 			 														System.out.println("Phone: " + curr.phone);
	 			 													if (curr.office != null)
	 			 														System.out.println("Office: " + curr.office);
	 			 													if (curr.officeHours != null) {
	 			 														System.out.print("Office Hours: ");
		 			 													for (officeHour currOfficeHour: curr.officeHours) {
		 			 														System.out.print(currOfficeHour.day + ": " );
		 			 														if (currOfficeHour.time != null)
		 			 															System.out.print(currOfficeHour.time.start + "-" + currOfficeHour.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 2) {
	 														//display TAs
	 														for (int i = 0; i < staffmembers.length; i++) {
	 															if (staffmembers[i].type.equals("ta")) {
	 																staffmember curr = staffmembers[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("TAs");
	 			 													if (curr.fname != null && curr.lname != null)
	 			 														System.out.println("Name: " + curr.fname + " " + curr.lname);
	 			 													if (curr.email != null)
	 			 														System.out.println("Email: " + curr.email);
	 			 													if (curr.image != null)
	 			 														System.out.println("Image: " + curr.image);
	 			 													if (curr.phone != null)
	 			 														System.out.println("Phone: " + curr.phone);
	 			 													if (curr.office != null)
	 			 														System.out.println("Office: " + curr.office);
	 			 													if (curr.officeHours != null) {
	 			 														System.out.print("Office Hours: ");
		 			 													for (officeHour currOfficeHour: curr.officeHours) {
		 			 														System.out.print(currOfficeHour.day + ": " );
		 			 														if (currOfficeHour.time != null)
		 			 															System.out.print(currOfficeHour.time.start + "-" + currOfficeHour.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 3) {
	 														for (int i = 0; i < staffmembers.length; i++) {
	 															if (staffmembers[i].type.equals("cp")) {
	 																staffmember curr = staffmembers[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("CPs");
	 			 													if (curr.fname != null && curr.lname != null)
	 			 														System.out.println("Name: " + curr.fname + " " + curr.lname);
	 			 													if (curr.email != null)
	 			 														System.out.println("Email: " + curr.email);
	 			 													if (curr.image != null)
	 			 														System.out.println("Image: " + curr.image);
	 			 													if (curr.phone != null)
	 			 														System.out.println("Phone: " + curr.phone);
	 			 													if (curr.office != null)
	 			 														System.out.println("Office: " + curr.office);
	 			 													if (curr.officeHours != null) {
	 			 														System.out.print("Office Hours: ");
		 			 													for (officeHour currOfficeHour: curr.officeHours) {
		 			 														System.out.print(currOfficeHour.day + ": " );
		 			 														if (currOfficeHour.time != null)
		 			 															System.out.print(currOfficeHour.time.start + "-" + currOfficeHour.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 4) {
	 														for (int i = 0; i < staffmembers.length; i++) {
	 															if (staffmembers[i].type.equals("grader")) {
	 																staffmember curr = staffmembers[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("Grader");
	 			 													if (curr.fname != null && curr.lname != null)
	 			 														System.out.println("Name: " + curr.fname + " " + curr.lname);
	 			 													if (curr.email != null)
	 			 														System.out.println("Email: " + curr.email);
	 			 													if (curr.image != null)
	 			 														System.out.println("Image: " + curr.image);
	 			 													if (curr.phone != null)
	 			 														System.out.println("Phone: " + curr.phone);
	 			 													if (curr.office != null)
	 			 														System.out.println("Office: " + curr.office);
	 			 													if (curr.officeHours != null) {
	 			 														System.out.print("Office Hours: ");
		 			 													for (officeHour currOfficeHour: curr.officeHours) {
		 			 														System.out.print(currOfficeHour.day + ": " );
		 			 														if (currOfficeHour.time != null)
		 			 															System.out.print(currOfficeHour.time.start + "-" + currOfficeHour.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 5) {
	 														flag6 = false;
	 													} else if (option6 == 6) {
	 														flag1 = false;
	 		 		 		 								flag2 = false;
	 		 		 		 								flag3 = false;
	 		 		 		 								flag4 = false;
	 		 		 		 								flag5 = false;
	 		 		 		 								flag6 = false;
	 		 		 		 								System.out.println();
	 		 		 		 								System.out.println("Thank you for using my program!");
	 													} else {
	 														System.out.println("This is not a valid option");
	 													}
	 												}
	 												
	 											} else if (option5 == 2) {			
	 												//display meeting infos
	 												boolean flag6 = true;
	 												while (flag6) {
	 													System.out.println();
	 													System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 													System.out.println("Meeting Information");
	 													System.out.println("1) Lecture");
	 													System.out.println("2) Lab");
	 													System.out.println("3) Quiz");
	 													System.out.println("4) Go to " + departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year + " Menu");
	 													System.out.println("5) Exit");
	 													System.out.println("What would you like to do? ");
	 													scanner = new Scanner(System.in);
	 													int option6 = scanner.nextInt();	
	 													
	 													if (option6 == 1) {
	 														//display lecture;
	 														for (int i = 0; i < meetings.length; i++) {
	 															if (meetings[i].type.equals("lecture")) {
	 																meeting curr = meetings[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("Lecture Meeting Information");
	 			 													if (curr.section != null)
	 			 														System.out.println("Section: " + curr.section);
	 			 													if (curr.room != null)
	 			 														System.out.println("Room: " + curr.room);
	 			 													if (curr.meetingPeriods != null) {
	 			 														System.out.print("Meeting Day And Time: ");
		 			 													for (meetingPeriod currPeriod: curr.meetingPeriods) {
		 			 														System.out.print(currPeriod.day + ": " );
		 			 														if (currPeriod.time != null)
		 			 															System.out.print(currPeriod.time.start + "-" + currPeriod.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 			 													if (curr.assistants != null) {
	 			 														System.out.print("Assistants: ");
	 			 														for (assistant currAssistant: curr.assistants) {
		 			 														if (currAssistant != null) {
		 			 															for (staffmember currStaffmember : staffmembers) {
		 			 																if (currAssistant.staffMemberID == currStaffmember.id) {
		 			 																	System.out.print(currStaffmember.fname + " " + currStaffmember.lname + ", ");
		 			 																}
		 			 															}
		 			 														}
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 2) {
	 														//display lab;
	 														for (int i = 0; i < meetings.length; i++) {
	 															if (meetings[i].type.equals("lab")) {
	 																meeting curr = meetings[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("Lab Meeting Information");
	 			 													if (curr.section != null)
	 			 														System.out.println("Section: " + curr.section);
	 			 													if (curr.room != null)
	 			 														System.out.println("Room: " + curr.room);
	 			 													if (curr.meetingPeriods != null) {
	 			 														System.out.print("Meeting Day And Time: ");
		 			 													for (meetingPeriod currPeriod: curr.meetingPeriods) {
		 			 														System.out.print(currPeriod.day + ": " );
		 			 														if (currPeriod.time != null)
		 			 															System.out.print(currPeriod.time.start + "-" + currPeriod.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 			 													if (curr.assistants != null) {
	 			 														System.out.print("Assistants: ");
	 			 														for (assistant currAssistant: curr.assistants) {
		 			 														if (currAssistant != null) {
		 			 															for (staffmember currStaffmember : staffmembers) {
		 			 																if (currAssistant.staffMemberID == currStaffmember.id) {
		 			 																	System.out.print(currStaffmember.fname + " " + currStaffmember.lname + ", ");
		 			 																}
		 			 															}
		 			 														}
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 3){
	 														for (int i = 0; i < meetings.length; i++) {
	 															if (meetings[i].type.equals("quiz")) {
	 																meeting curr = meetings[i];
	 																System.out.println();
	 																System.out.println(departments[option3 - 1].prefix + " " + courses[option4 - 1].number + " " + courses[option4 - 1].term + " " + courses[option4 - 1].year);
	 			 													System.out.println("Quiz Meeting Information");
	 			 													if (curr.section != null)
	 			 														System.out.println("Section: " + curr.section);
	 			 													if (curr.room != null)
	 			 														System.out.println("Room: " + curr.room);
	 			 													if (curr.meetingPeriods != null) {
	 			 														System.out.print("Meeting Day And Time: ");
		 			 													for (meetingPeriod currPeriod: curr.meetingPeriods) {
		 			 														System.out.print(currPeriod.day + ": " );
		 			 														if (currPeriod.time != null)
		 			 															System.out.print(currPeriod.time.start + "-" + currPeriod.time.end + "   ");
		 			 													}
	 			 													}
	 			 													System.out.println();
	 			 													if (curr.assistants != null) {
	 			 														System.out.print("Assistants: ");
	 			 														for (assistant currAssistant: curr.assistants) {
		 			 														if (currAssistant != null) {
		 			 															for (staffmember currStaffmember : staffmembers) {
		 			 																if (currAssistant.staffMemberID == currStaffmember.id) {
		 			 																	System.out.print(currStaffmember.fname + " " + currStaffmember.lname + ", ");
		 			 																}
		 			 															}
		 			 														}
		 			 													}
	 			 													}
	 			 													System.out.println();
	 															}
	 														}
	 													} else if (option6 == 4) {
	 														flag6 = false;
	 													} else if (option6 == 5) {
	 														flag1 = false;
	 		 		 		 								flag2 = false;
	 		 		 		 								flag3 = false;
	 		 		 		 								flag4 = false;
	 		 		 		 								flag5 = false;
	 		 		 		 								flag6 = false;
	 		 		 		 								System.out.println();
	 		 		 		 								System.out.println("Thank you for using my program!");
	 													} else {
	 														System.out.println("This is not a valid option");
	 													}
	 												}
	 											} else if (option5 == 3){
	 												flag5 = false;
	 											} else if (option5 == 4) {
	 												flag1 = false;
	 		 		 								flag2 = false;
	 		 		 								flag3 = false;
	 		 		 								flag4 = false;
	 		 		 								flag5 = false;
	 		 		 								System.out.println();
	 		 		 				 				System.out.println("Thank you for using my program!");
	 											} else {
	 												System.out.println("This is not a valid option");
	 											}
	 										}
	 										
	 									} else if (option4 == size4 + 1) {
	 										flag4 = false;
	 									} else if (option4 == size4 + 2){
	 										flag1 = false;
	 		 								flag2 = false;
	 		 								flag3 = false;
	 		 								flag4 = false;
	 		 								System.out.println();
	 		 				 				System.out.println("Thank you for using my program!");
	 									} else {
	 										System.out.println("This is not a valid option");
	 									}
	 								}
	 								
	 							} else if (option3 == size3 + 1) {
	 								flag3 = false;
	 							} else if (option3 == size3 + 2){
	 								flag1 = false;
	 								flag2 = false;
	 								flag3 = false;
	 								System.out.println();
	 				 				System.out.println("Thank you for using my program!");
	 							} else {
	 								System.out.println("This is not a valid option");
	 							}
	 						}
	 					} else if (option2 == size2 + 1) {
	 						flag2 = false;
	 					} else if (option2 == size2 + 2){
	 						flag1 = false;
	 						flag2 = false;
	 						System.out.println();
	 		 				System.out.println("Thank you for using my program!");
	 					} else {
	 						System.out.println("This is not a valid option");
	 					}
	 				}
	 			} else if (option1 == 2) {
	 				flag1 = false;
	 				System.out.println();
	 				System.out.println("Thank you for using my program!");
	 			} else {
	 				System.out.println("This is not a valid option");
	 			}
	 		}
	         
	         scanner.close();

	      } catch (FileNotFoundException fnfe) {
	    	System.out.println("That file could not be found. ");
			System.out.println("FileNotFoundException: " + fnfe.getMessage());
	      } catch (IOException ioe) {
			System.out.println("IOException: " + ioe.getMessage());
	      } catch (Exception e) {
	    	  System.out.println("That file is not a well-formed XML file. ");
	          //e.printStackTrace();
	      } 
		
		  
	}
	
	public static class school {
		public String name;
		department[] departments;
		public school () {}
		public school (String name, department[] departments) {
			this.name = name;
			this.departments = departments;
		}
	}

	public static class department {
		public String longName;
		public String prefix;
		public course[] courses;
		public department () {}
		public department (String longName, String prefix, course[] courses) {
			this.longName = longName;
			this.prefix = prefix;
			this.courses = courses;
		}
	}
	
	public static class course {
		public int number;
		public String term;
		public int year;
		public staffmember[] staffmembers;
		public meeting[] meetings;
		public course () {}
		public course (int number, String term, int year, staffmember[] staffmembers, meeting[] meetings) {
			this.number = number;
			this.term = term;
			this.year = year;
			this.staffmembers = staffmembers;
			this.meetings = meetings;
		}
	}
	
	public static class staffmember {
		public String type;
		public int id;
		public String fname;
		public String lname;
		public String email;
		public String image;
		public String phone;
		public String office;
		public officeHour[] officeHours;
		public staffmember () {}
		public staffmember (String type, int id, String fname, String lname,
							String email, String image, String phone, String office, officeHour[] officeHours) {
			this.type = type;
			this.id = id;
			this.fname = fname;
			this.lname = lname;
			this.email = email;
			this.image = image;
			this.phone = phone;
			this.office = office;
			this.officeHours = officeHours;
		}
	}
	
	public static class officeHour {
		public String day;
		public Time time;
		public officeHour () {}
		public officeHour (String day, Time time) {
			this.day = day;
			this.time = time;
		}
	}
	
	public static class Time {
		public String start;
		public String end;
		public Time () {}
		public Time (String start, String end) {
			this.start = start;
			this.end = end;
		}
	}
	
	public static class meeting {
		public String type;
		public String section;
		public String room;
		public meetingPeriod[] meetingPeriods; 
		public assistant[] assistants;
		public meeting () {}
		public meeting (String type, String section, String room, meetingPeriod[] meetingPeriods, assistant[] assistants) {
			this.type = type;
			this.section = section;
			this.room = room;
			this.meetingPeriods = meetingPeriods;
			this.assistants = assistants;
		}
	}
	
	public static class meetingPeriod {
		public String day;
		public Time time;
		public meetingPeriod () {}
		public meetingPeriod(String day, Time time) {
			this.day = day;
			this.time = time;
		}
	}
	
	public static class assistant {
		public int staffMemberID;
		public assistant () {}
		public assistant(int id) {
			this.staffMemberID = id;
		}
	}
}


